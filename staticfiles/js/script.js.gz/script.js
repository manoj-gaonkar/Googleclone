tailwind.config = {
    darkMode: 'class',
      theme: {
        extend: {
          colors: {
            clifford: '#da373d',
          }
        }
      }
    }